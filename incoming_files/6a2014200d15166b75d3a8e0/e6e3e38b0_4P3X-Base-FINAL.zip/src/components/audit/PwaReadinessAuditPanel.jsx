import React from 'react';
import { Card } from '../ui/Card.jsx';

export function PwaReadinessAuditPanel({ result }) {
  if (!result) return null;
  const ok = (result.blockers || []).length === 0;
  return (
    <Card variant="default">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div className="card-title">PWA Readiness</div>
        <span style={{ fontSize: 12, fontWeight: 700, color: ok ? '#22c55e' : '#ef4444' }}>
          {ok ? '✓ PASS' : '⛔ FAIL'} — {result.score}/100
        </span>
      </div>
      <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>
        Manifest exists: {result.details?.manifestExists ? '✓' : '✗'} ·
        Fields valid: {result.details?.manifestFieldsOk ? '✓' : '✗'}
        {result.details?.missingFields?.length > 0 && ` · Missing: ${result.details.missingFields.join(', ')}`}
      </div>
      {(result.blockers || []).map((b, i) => <div key={i} style={{ fontSize: 11, color: '#ef4444', marginBottom: 3 }}>⛔ {b}</div>)}
      {(result.warnings || []).map((w, i) => <div key={i} style={{ fontSize: 11, color: '#f59e0b', marginBottom: 3 }}>⚠ {w}</div>)}
      {(result.passed  || []).map((p, i) => <div key={i} style={{ fontSize: 11, color: '#22c55e', marginBottom: 3 }}>✓ {p}</div>)}
    </Card>
  );
}
export default PwaReadinessAuditPanel;
